import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const RptMobile());
}

class RptMobile extends StatelessWidget {
  const RptMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RPT Mobile',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: const HomePage(),
    );
  }
}

class Personagem {
  final String nome;
  final String raca;
  final String classe;
  final String antecedente;

  Personagem({
    required this.nome,
    required this.raca,
    required this.classe,
    required this.antecedente,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int resultadoDado = 1;
  List<Personagem> personagens = [];

  void rolarDado() {
    setState(() {
      resultadoDado = Random().nextInt(20) + 1;
    });
  }

  void adicionarPersonagem() async {
    final nomeController = TextEditingController();
    String? racaSelecionada;
    String? classeSelecionada;
    String? antecedenteSelecionado;

    final personagem = await showDialog<Personagem>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Novo Personagem'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nomeController,
                  decoration: const InputDecoration(
                    labelText: 'Nome do personagem',
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Raça'),
                  items: const [
                    DropdownMenuItem(value: 'Humano', child: Text('Humano')),
                    DropdownMenuItem(value: 'Elfo', child: Text('Elfo')),
                    DropdownMenuItem(value: 'Anão', child: Text('Anão')),
                    DropdownMenuItem(value: 'Orc', child: Text('Orc')),
                  ],
                  onChanged: (value) => racaSelecionada = value,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Classe'),
                  items: const [
                    DropdownMenuItem(value: 'Mago', child: Text('Mago')),
                    DropdownMenuItem(value: 'Guerreiro', child: Text('Guerreiro')),
                    DropdownMenuItem(value: 'Ladino', child: Text('Ladino')),
                    DropdownMenuItem(value: 'Clérigo', child: Text('Clérigo')),
                    DropdownMenuItem(value: 'Arqueiro', child: Text('Arqueiro')),
                  ],
                  onChanged: (value) => classeSelecionada = value,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Antecedente'),
                  items: const [
                    DropdownMenuItem(value: 'Nobre', child: Text('Nobre')),
                    DropdownMenuItem(value: 'Soldado', child: Text('Soldado')),
                    DropdownMenuItem(value: 'Acolito', child: Text('Acolito')),
                    DropdownMenuItem(value: 'Criminoso', child: Text('Criminoso')),
                    DropdownMenuItem(value: 'Artesão', child: Text('Artesão')),
                  ],
                  onChanged: (value) => antecedenteSelecionado = value,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nomeController.text.isEmpty ||
                    racaSelecionada == null ||
                    classeSelecionada == null ||
                    antecedenteSelecionado == null) {
                  return;
                }
                Navigator.pop(
                  context,
                  Personagem(
                    nome: nomeController.text,
                    raca: racaSelecionada!,
                    classe: classeSelecionada!,
                    antecedente: antecedenteSelecionado!,
                  ),
                );
              },
              child: const Text('Criar Personagem'),
            ),
          ],
        );
      },
    );

    if (personagem != null) {
      setState(() {
        personagens.add(personagem);
      });
    }
  }

  void removerPersonagem(int index) {
    setState(() {
      personagens.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rpt Mobile'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Dado d20
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.casino, color: Colors.deepPurple),
                        SizedBox(width: 8),
                        Text(
                          'Dado d20',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Resultado: $resultadoDado',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: rolarDado,
                      child: const Text('Rolar'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            // Lista de personagens
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Personagens',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: adicionarPersonagem,
                  icon: const Icon(Icons.add),
                  label: const Text('Adicionar'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: personagens.isEmpty
                  ? const Center(
                child: Text(
                  'Nenhum personagem\nAdicione um personagem para começar',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54),
                ),
              )
                  : ListView.builder(
                itemCount: personagens.length,
                itemBuilder: (context, index) {
                  final p = personagens[index];
                  return Card(
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: ListTile(
                      title: Text(
                        p.nome,
                        style:
                        const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        'Raça: ${p.raca} | Classe: ${p.classe} | Antecedente: ${p.antecedente}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: Colors.redAccent),
                        onPressed: () => removerPersonagem(index),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
